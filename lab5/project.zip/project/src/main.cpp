#include <GL/glew.h> // Включение заголовочного файла GLEW должно быть первым
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/OpenGL.hpp>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <iostream>
#include <vector>
#include <cmath>

using namespace glm;

// Структура луча
struct Ray {
    vec3 origin;
    vec3 direction;

    Ray(const vec3& ori, const vec3& dir) : origin(ori), direction(normalize(dir)) {}
};

// Базовый класс для объектов сцены
class SceneObject {
public:
    virtual bool intersect(const Ray& ray, float& t) const = 0;
    virtual vec3 getNormal(const vec3& point) const = 0;
    virtual vec3 getColor() const = 0;
    virtual float getReflectivity() const = 0;
};

// Класс сферы
class Sphere : public SceneObject {
public:
    vec3 center;
    float radius;
    vec3 color;
    float reflectivity;

    Sphere(const vec3& c, float r, const vec3& col, float refl) : center(c), radius(r), color(col), reflectivity(refl) {}

    bool intersect(const Ray& ray, float& t) const override {
        vec3 oc = ray.origin - center;
        float a = dot(ray.direction, ray.direction);
        float b = 2.0 * dot(oc, ray.direction);
        float c = dot(oc, oc) - radius * radius;
        float discriminant = b * b - 4 * a * c;
        if (discriminant < 0) return false;
        t = (-b - sqrt(discriminant)) / (2.0 * a);
        return t > 0;
    }

    vec3 getNormal(const vec3& point) const override {
        return normalize(point - center);
    }

    vec3 getColor() const override {
        return color;
    }

    float getReflectivity() const override {
        return reflectivity;
    }
};

// Класс плоскости
class Plane : public SceneObject {
public:
    vec3 point;  // Точка на плоскости
    vec3 normal; // Нормаль плоскости
    vec3 color;
    float reflectivity;

    Plane(const vec3& p, const vec3& n, const vec3& col, float refl) : point(p), normal(normalize(n)), color(col), reflectivity(refl) {}

    bool intersect(const Ray& ray, float& t) const override {
        float denom = dot(normal, ray.direction);
        if (fabs(denom) > 1e-6) {
            t = dot(point - ray.origin, normal) / denom;
            return t >= 0;
        }
        return false;
    }

    vec3 getNormal(const vec3& /*point*/) const override {
        return normal;
    }

    vec3 getColor() const override {
        return color;
    }

    float getReflectivity() const override {
        return reflectivity;
    }
};

// Функция трассировки лучей
vec3 trace(const Ray& ray, const std::vector<SceneObject*>& objects, int depth) {
    const int maxDepth = 5;
    if (depth > maxDepth) return vec3(0.0f);

    float tMin = FLT_MAX;
    const SceneObject* hitObject = nullptr;

    // Поиск пересечений
    for (const auto& object : objects) {
        float t = 0;
        if (object->intersect(ray, t) && t < tMin) {
            tMin = t;
            hitObject = object;
        }
    }

    if (!hitObject) return vec3(0.0f); // Фон

    vec3 hitPoint = ray.origin + tMin * ray.direction;
    vec3 normal = hitObject->getNormal(hitPoint);
    vec3 color = hitObject->getColor();
    float reflectivity = hitObject->getReflectivity();

    // Освещение (простой фонарик)
    vec3 lightPos = vec3(5.0f, 5.0f, -10.0f);
    vec3 lightDir = normalize(lightPos - hitPoint);
    float lightIntensity = dot(normal, lightDir);
    lightIntensity = clamp(lightIntensity, 0.0f, 1.0f);

    vec3 finalColor = color * lightIntensity;

    // Отражения
    if (reflectivity > 0) {
        vec3 reflectDir = reflect(ray.direction, normal);
        Ray reflectRay(hitPoint + normal * 0.001f, reflectDir); // Смещение для предотвращения самоинтерсекции
        vec3 reflectColor = trace(reflectRay, objects, depth + 1);
        finalColor = mix(finalColor, reflectColor, reflectivity);
    }

    return finalColor;
}

int main() {
    // Настройка окна
    sf::RenderWindow window(sf::VideoMode(800, 600), "Ray Tracing");

    // Инициализация GLEW
    glewExperimental = GL_TRUE;
    if (glewInit() != GLEW_OK) {
        std::cerr << "Failed to initialize GLEW" << std::endl;
        return -1;
    }

    // Создание сцены
    std::vector<SceneObject*> objects;
    objects.push_back(new Sphere(vec3(0.0f, 0.0f, -10.0f), 2.0f, vec3(0.7f, 0.3f, 0.3f), 0.5f));
    objects.push_back(new Sphere(vec3(3.0f, -1.0f, -8.0f), 1.0f, vec3(0.3f, 0.7f, 0.3f), 0.3f));
    objects.push_back(new Plane(vec3(0.0f, -2.0f, 0.0f), vec3(0.0f, 1.0f, 0.0f), vec3(0.8f, 0.8f, 0.8f), 0.1f));

    // Камера
    vec3 cameraPos = vec3(0.0f, 0.0f, 0.0f);
    float fov = 90.0f;
    float aspectRatio = window.getSize().x / static_cast<float>(window.getSize().y);
    float scale = tan(radians(fov * 0.5f));

    // Углы поворота камеры
    float yaw = 0.0f;
    float pitch = 0.0f;

    // Буфер для рендеринга
    sf::Image image;
    image.create(window.getSize().x, window.getSize().y);
    sf::Texture texture;
    texture.loadFromImage(image);
    sf::Sprite sprite(texture);

    // Основной цикл
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            } else if (event.type == sf::Event::KeyPressed) {
                if (event.key.code == sf::Keyboard::Up) {
                    pitch -= 5.0f;
                } else if (event.key.code == sf::Keyboard::Down) {
                    pitch += 5.0f;
                } else if (event.key.code == sf::Keyboard::Left) {
                    yaw -= 5.0f;
                } else if (event.key.code == sf::Keyboard::Right) {
                    yaw += 5.0f;
                }
            }
        }

        // Очистка буфера цвета и глубины
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // Рендеринг сцены
        for (unsigned y = 0; y < window.getSize().y; ++y) {
            for (unsigned x = 0; x < window.getSize().x; ++x) {
                float i = (2 * (x + 0.5f) / static_cast<float>(window.getSize().x) - 1) * aspectRatio * scale;
                float j = (1 - 2 * (y + 0.5f) / static_cast<float>(window.getSize().y)) * scale;

                // Обновление направления луча на основе углов yaw и pitch
                vec3 rayDir = normalize(vec3(i, j, -1));
                mat4 rotation = rotate(mat4(1.0f), radians(yaw), vec3(0.0f, 1.0f, 0.0f)) * rotate(mat4(1.0f), radians(pitch), vec3(1.0f, 0.0f, 0.0f));
                rayDir = vec3(rotation * vec4(rayDir, 0.0f));

                Ray ray(cameraPos, rayDir);

                vec3 color = trace(ray, objects, 0);
                image.setPixel(x, y, sf::Color(color.r * 255, color.g * 255, color.b * 255));
            }
        }

        // Обновление текстуры
        texture.update(image);

        // Отрисовка спрайта
        window.clear();
        window.draw(sprite);
        window.display();
    }

    // Очистка объектов сцены
    for (auto object : objects) {
        delete object;
    }

    return 0;
}